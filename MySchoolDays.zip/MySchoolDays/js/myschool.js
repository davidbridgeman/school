$(document).ready(function() {

	$("#infoaboutme").hide();

	$("#aboutme").click(function() {

		$("#infoaboutme").fadeToggle(500);

	});
	
	//mouseover effects//
	
	$("#welcome").mouseenter(function() {
		$(this).css("font-size", "3em");
		$(this).css("color","red")
	});

	$("#welcome").mouseleave(function() {
		$(this).css("font-size", "2em");
		$(this).css("color","black")
		/* $(this).unbind(); makes it happen one time only */
	});

});
