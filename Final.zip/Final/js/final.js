window.addEventListener('load', function() {
	
//size of the game
var CANVAS_WIDTH = 900;
var CANVAS_HEIGHT = 400;
var GAME_WIDTH = 900;
var GAME_HEIGHT = 360; 
	
var sprites = {};
	
//pausing variable
var gameLive = true;

//goal
var goal = {x: 850, y: 0, w: 50, h: 400};	

//player
var player = {x: 10, y: 160, speedX: 2, w: 40, h: 40, isMoving: false};

//move the player
var movePlayer = function() {
	player.isMoving = true;
};
	
//stop the player	
var stopPlayer = function() {
	player.isMoving = false;
};		

//enemies
var enemies = [ {x : 100, y : 10, speedY : 1, w : 40, h : 40, myColor : "#FFFF00"},
				{x : 225, y : 20, speedY : 5, w : 40, h : 40, myColor : "#FF0000"},
				{x : 360, y : 40, speedY : 4, w : 40, h : 40, myColor : "#FFFF00"},
				{x : 500, y : 50, speedY : 3, w : 40, h : 40, myColor : "#FF9900"},
				{x : 700, y : 90, speedY : 2, w : 40, h : 40, myColor : "#FFCC00"}];			
								
//loading the sprite images					
var load = function() {
				
	sprites.player = new Image();
	sprites.player.src = 'img/hero.png';
				
	sprites.background = new Image();
	sprites.background.src = 'img/floor.gif';
				
	sprites.enemy = new Image();
	sprites.enemy.src = 'img/enemy.png';
				
	sprites.goal = new Image();
	sprites.goal.src = 'img/chest.png';
};
			
//targeting the canvas
var canvas = document.getElementById("myCanvas");
var ctx = canvas.getContext("2d");

//moving the player			
canvas.addEventListener("mousedown", movePlayer);
canvas.addEventListener("mouseup", stopPlayer);

//things that happen in the game
var update = function() {
	
	//update enemies	
	var j = 0;
	var n = enemies.length;
					
	//check for entering the goal
	if(checkCollision(player, goal)) {		
		gameLive = false; //pause game
		alert('You win!'); //popup window
		window.location = ""; //restart game
	}
				
	// update player
	if (player.isMoving) {	
		player.x += player.speedX;	
	}
	
	//foreach looping
	enemies.forEach(function(element, index) {
		element.y += element.speedY;
		
		//check collision with enemy
		if(checkCollision(player, element)){
			gameLive = false;
			alert('Game over!');
			window.location = "";	
		}
		
		//check enemy collision with botton
		if (element.y >= GAME_HEIGHT) {
			element.y = GAME_HEIGHT;
			element.speedY *= -1;
			
		//check enemy collision with top
		} else if (element.y <= 0) {
			element.y = 0;
			element.speedY *= -1;
		}
	});
};
			
//showing the game on the screen
var draw = function() {
				
	//clear the canvas
	ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
				
	//draw background
	ctx.drawImage(sprites.background, 0, 0);
				
	//draw player
	ctx.drawImage(sprites.player, player.x, player.y);
				
	//draw enemies
	ctx.drawImage(sprites.enemy, enemies.x, enemies.y);
				
	//draw goal
	ctx.drawImage(sprites.goal, goal.x, goal.y);
	
	//targeting multiple enemies
	enemies.forEach(function(element, index) {
		ctx.drawImage(sprites.enemy, element.x, element.y);
	});
	
	var myColor = "#FFFF00";
	var j = 0;
	var n = enemies.length;
};

//moving the player, pausing
var step = function() {

	update();
	draw();

	if (gameLive){
		window.requestAnimationFrame(step);
	}
};

//checking if the player has hit the enemies
var checkCollision = function(rect1, rect2){
	var closeOnWidth = Math.abs(rect1.x - rect2.x) <= Math.max(rect1.w, rect2.w);
	var closeOnHeight =Math.abs(rect1.y - rect2.y) <= Math.max(rect1.h, rect2.h);
	return closeOnHeight && closeOnWidth;
};

//running the game
load();
step();
			
});