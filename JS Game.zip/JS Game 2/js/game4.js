window.addEventListener('load', function(){        
            var GAME_WIDTH = 700;
            var GAME_HEIGHT = 360;
            var CANVAS_WIDTH = 900;
            var CANVAS_HEIGHT = 400;
            
            var sprites = {
                
                
            };
            
            var gameLive = true;
            
            var goal = {
            x: 840,
            y: 180,
            w: 50,
            h: 36
            };
            
            var player = {
                x: 10,
                y: 180,
                speedX: 2,
                w: 40,
                h: 40,
                isMoving: false
            };
            
            var movePlayer = function() {
        
                player.isMoving = true;
        
            };
            var stopPlayer = function() {
                player.isMoving = false;
            };
            

            
            //arry [] holds MANY values
            
            var enemies = [{
            x : 90,
            y : 25,
            speedY : 1,
            w : 40,
            h : 40,
            myColor : "#ff0000"
            },
             {
            x : 180,
            y : 50,
            speedY : 2,
            w : 40,
            h : 40,
            myColor : "#FF0000"
            }, 
            {
            x : 270,
            y : 75,
            speedY : 3,
            w : 40,
            h : 40,
            myColor : "#FF8800"
            }, 
            {
            x : 360,
            y : 100,
            speedY : 4,
            w : 40,
            h : 40,
            myColor : "ffff00"
            },
            {
            x : 540,
            y : 150,
            speedY : 6,
            w : 40,
            h : 40,
            myColor : "#6666ff"
            },
            {
            x : 720,
            y : 200,
            speedY : 8,
            w : 40,
            h : 40,
            myColor : "#ff99cc"
            },
            {
            x : 810,
            y : 225,
            speedY : 9,
            w : 40,
            h : 40,
            myColor : "#9900cc"
            },
            ];
            
            var load = function(){
                sprites.player = new Image();
                sprites.player.src= 'sprites/hero.png';
            
                sprites.goal = new Image();
                sprites.goal.src = 'sprites/chest.png';

                sprites.enemy = new Image();
                sprites.enemy.src = 'sprites/enemy.png';

                sprites.background = new Image();
                sprites.background.src = 'sprites/floor.png';    
        };
            
            var canvas = document.getElementById("myCanvas");
            var ctx = canvas.getContext("2d");
            
            canvas.addEventListener("mousedown", movePlayer );
            canvas.addEventListener("mouseup", stopPlayer );
            
            
            

    var update = function() {

        var j = 0;
        var n = enemies.length;

        if (checkCollision(player, goal)) {

            gameLive = false;
            alert('YESSS!! You are the awesome winnner!!');
            // later bump up the difficulty level here
            window.location = "";

        }

        if (player.isMoving) {
            player.x += player.speedX;
        }

        // EXAMPLE OF FOREACH LOOPING
        enemies.forEach(function(element, index) {
            element.y += element.speedY;

            // test for collision between player and EACH of the enemies
            if (checkCollision(player, element)) {
                gameLive = false;
                alert('Oh NO! Collision! Game busted!');
                window.location = "";
            }

            if (element.y >= GAME_HEIGHT) {// check if hitting the bottom, if so flip direction

                element.y = GAME_HEIGHT;
                element.speedY *= -1;
            } else if (element.y <= 0) {// check if hitting top

                element.y = 0;
                element.speedY *= -1;
            }
        });
        // end of forEach

    };
    // end of update






            //beg of draw
            //beg of draw
            //beg of draw
            var draw = function() {
            ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
            
            ctx.drawImage(sprites.background, 0, 0);
            ctx.drawImage(sprites.player, player.x, player.y);
            ctx.drawImage(sprites.goal, goal.x, goal.y);
            
            enemies.forEach(function(element, index){
                ctx.drawImage(sprites.enemy, element.x, element.y);
            });
            
            var myColor = "#FFFF00";
            var j = 0;
            var n = enemies.length;
            
            
            
            
            //ctx.fillStyle = "rgba(128, 128, 0, 0.6)";
            //ctx.fillRect(goal.x, goal.y, goal.w, goal.h);
            
            //ctx.fillStyle = "sprites/";
            //ctx.fillRect(player.x, player.y, player.w, player.h);


            
    // EXAMPLE OF FOR LOOPING
    //for (var j = 0; j < enemies.length; j++) {

        //if (enemies[j].speedY > 0) {// going down
        //    ctx.fillStyle = enemies[j].downColor;
        //} else if (enemies[j].speedY < 0) {// going up
        //    ctx.fillStyle = enemies[j].upColor;
        //} else {
        //    ctx.fillStyle = "#000000";
        //}

    //    ctx.fillRect(enemies[j].x, enemies[j].y, enemies[j].w, enemies[j].h);

    //}

    }; // end of draw()


            var step = function() {
            update();
            draw();
            
            if (gameLive) {
            window.requestAnimationFrame(step);
            };
            
            };

            //check collision
            var checkCollision = function(rect1, rect2) {
                
                var closeOnWidth = Math.abs(rect1.x - rect2.x) <= Math.max(rect1.w, rect2.w);
                var closeOnHeight = Math.abs(rect1.y - rect2.y) <= Math.max(rect1.h, rect2.h);
                
                return closeOnHeight && closeOnWidth;
            };
            
            load();
            step();
            
});  //end of load event




