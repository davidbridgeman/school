window.addEventListener('load', function() {
	
	var movePlayer = function() {
			player.isMoving = true;
	};
	
	var stopPlayer = function() {
			player.isMoving = false;
	};
	
//targeting the canvas
var canvas = document.getElementById("myCanvas");
var ctx = canvas.getContext("2d");

//moving the player			
canvas.addEventListener("mousedown", movePlayer);
canvas.addEventListener("mouseup", stopPlayer);
	
			//size of the game
			var CANVAS_WIDTH = 900;
			var CANVAS_HEIGHT = 400;
			var GAME_WIDTH = 900;
			var GAME_HEIGHT = 360; 
			
			//pausing variable
			var gameLive = true;
			
			//player
			var player = {x: 10, y: 160, speedX: 2, w: 40, h: 40, isMoving: false};
			
			//goal
			var goal = {x: 850, y: 0, w: 50, h: 400};
			
			//enemies
			var enemies = [ {x : 100, y : 10, speedY : 1, w : 40, h : 40, myColor : "#FFFF00"},
							{x : 225, y : 20, speedY : 5, w : 40, h : 40, myColor : "#FF0000"},
							{x : 360, y : 40, speedY : 4, w : 40, h : 40, myColor : "#FFFF00"},
							{x : 500, y : 50, speedY : 3, w : 40, h : 40, myColor : "#FF9900"},
							{x : 700, y : 90, speedY : 2, w : 40, h : 40, myColor : "#FFCC00"}];
								
			//loading the sprite images					
			var load = function() {
				
				sprites.player = new Image();
				sprites.player.src = 'images/hero.png';
				
				sprites.background = new Image();
				sprites.background.src = 'images/floor.png';
				
				sprites.enemy = new Image();
				sprites.enemy.src = 'images/enemy.png';
				
				sprites.goal = new Image();
				sprites.goal.src = 'images/chest.png';
			};

			//things that happen in the game
			var update = function() {
					
				//check for entering the goal
				if(checkCollision(player, goal)) {
					
					gameLive = false; //pause game
					alert('You win!'); //popup window
					window.location = ""; //restart game
				}
				
				// update player
				if (player.isMoving) {	
					player.x += player.speedX;	
				}
				
				// update enemies
				var j = 0;
				var n = enemies.length;
				
				
					for (var j = 0; j < enemies.length; j++){ 
						
						//check collision with enemy
						if(checkCollision(player,enemies[j])){
						gameLive = false;
						alert('Game over!');
						window.location = "";	
						}
						
					enemies[j].y += enemies[j].speedY;
					
					if (enemies[j].y >= GAME_HEIGHT) {
						
						enemies[j].y = GAME_HEIGHT;
						enemies[j].speedY *= -1;

					} else if (enemies[j].y <= 0) {
						
						enemies[j].y = 0;
						enemies[j].speedY *= -1;
					}
				}
			};
			
			//showing the game on the screen
			var draw = function() {
				
				//clear the canvas
				ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
				
				//draw background
				ctx.drawImage(sprites.background, 0, 0);
				
				//draw player
				ctx.drawImage(sprites.player, player.x, player.y);
				
				//draw enemies
				ctx.drawImage(sprites.enemy, enemies.x, enemies.y);
				
				//draw goal
				ctx.drawImage(sprites.goal, goal.x, goal.y);
				
				enemies.forEach(element, index) {
					ctx.drawImage(sprites.enemy, element.x, element.y);
				};
				
				//player
				ctx.fillStyle = "#00FF00";
				ctx.fillRect(player.x, player.y, player.w, player.h);
				
				//goal styling
				ctx.fillStyle = "rgb(128, 200, 0)";
				ctx.fillRect(goal.x, goal.y, goal.w, goal.h);
				
				var myColor = "#FFFF00";

				var j = 0;
				var n = enemies.length;

				while (j < n) {
					
					if (enemies[j].speedY > 0 ){ // if the enemies are going down, use custom color
					ctx.fillStyle = enemies[j].myColor;
					}
					
					else if (enemies[j].speedY < 0 ){ //if the enemies are going up, use blue
						ctx.fillStyle = "#0000FF";
					}
					
					else {
						ctx.fillStyle = "#000000";
					}
					
					ctx.fillRect(enemies[j].x, enemies[j].y, enemies[j].w, enemies[j].h);
					j++;
				}

			};

			//moving the player, pausing
			var step = function() {

				update();
				draw();

				if (gameLive){
					window.requestAnimationFrame(step);
				}
			};
			
			//checking if the player has hit the enemies
			var checkCollision = function(rect1, rect2){
				var closeOnWidth = Math.abs(rect1.x - rect2.x) <= Math.max(rect1.w, rect2.w);
				var closeOnHeight =Math.abs(rect1.y - rect2.y) <= Math.max(rect1.h, rect2.h);
				return closeOnHeight && closeOnWidth;
			};

			//running the game
			load();
			step();
			
			});
