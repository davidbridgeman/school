var ctx = document.getElementById("ctx").getContext("2d");

var ctxHeight = 500;
var ctxWidth = 500;
var rtSpacing = 20;
var topSpacing = 20;
var millisec = 20;

var horizColor = "#FF0000";
var vertColor = "#0000FF";

var skyBlue = "#0000FF";
var appleRed = "#FF0000";
var grassGreen = "#00FF00";
var canaryYellow = "#FFFF00";
var myBlack = "#000000";
var flamingoPink = "rgba(255, 102, 204, 0.5)";

var enemyList = {};

var player = {
	x : 300,
	spdX : 3,
	y : 300,
	spdY : 5,
	name : "P",
	color : myBlack,
	wallColor: grassGreen,
	topBottomColor: skyBlue,
	font : "50px Arial"
};

Enemy = function(id,passX,passY,spdX,spdY,passName,passFont,passWallFont,passTopBottomFont,passColor,passColorWall,passColorTopBottom) {
	
	var enemy = {
		id : id,
		x : passX,
		y : passY,
		spdX : spdX,
		spdY : spdY,
		name : passName,
		font : passFont,
		wallFont : passWallFont,
		topBottomFont : passTopBottomFont,
		color : passColor,
		colorWall : passColorWall,
		colorTopBottom : passColorTopBottom
	};
	enemyList[id] = enemy;
};

getDistanceBetweenEntity = function(entity1,entity2) {
	
	var dx = entity1.x - entity2.x;
	var dy = entity1.y - entity2.y;
	return Math.sqrt(dx*dx + dy*dy);
};

testCollisionEntity = function(entity1,entity2) {
	
	var distance = getDistanceBetweenEntity(entity1,entity2);
	return distance < 50;
};

updateEntity = function(something) {
	updateEntityPosition(something);
	drawEntity(something);
};

updateEntityPosition = function(something) {

	something.x += something.spdX;
	something.y += something.spdY;

	// reverse direction if it hits the right wall or the left wall
	if (something.x >= ctxWidth - rtSpacing || something.x <= 0) {
		something.spdX = -something.spdX;
		something.color = something.wallColor;
		something.font = something.wallFont;

	}
	// reverse direction if it hits the floor or the ceiling
	if (something.y >= ctxHeight || something.y <= topSpacing) {
		something.spdY = -something.spdY;
		something.color = something.topBottomColor;
		something.font = something.topBottomFont;

	}

	ctx.fillStyle = something.color;
	ctx.font = something.font;
	ctx.fillText(something.name, something.x, something.y);

};

update = function() {
	ctx.clearRect(0, 0, ctxWidth, ctxHeight);
	entityUpdate(player);
	
	for (var xyz in enemyList) {
		entityUpdate(enemyList[xyz]);
		var isColliding = testCollisionEntity(player,enemyList[xyz]);
		if (isColliding) {
			console.log('Colliding');
		}
	}
};

Enemy('E1', 70, 60, 2, 4, 'E03', '30px Arial', '60px Arial', '10px Arial', grassGreen, canaryYellow, appleRed);
Enemy('E2', 80, 50, 3, 4, 'E03', '10px Arial', '50px Arial', '20px Arial', myBlack, grassGreen, appleRed);
Enemy('E3', 75, 50, 3, 7, 'E03', '40px Arial', '70px Arial', '30px Arial', canaryYellow, appleRed, myBlack);

setInterval(update, millisec);
