var ctx = document.getElementById("ctx").getContext("2d");

var appleRed = "#FF0000";
var skyBlue = "#0000FF";
var grassGreen = "#00FF00";
var canaryYellow = "#FFFF00";
var myBlack = "#000000";
var myPink = "rgba(255, 102, 153, 0.5)";

var enemyList = {};

// player
var player = {
	x : 50,
	spdX : 3,
	y : 40,
	spdY : 7,
	name : "David",
	startFont : '30px Arial',
	wallFont : '20px Arial',
	topBottomFont : '10px Arial',
	color : myPink,
	colorWall : canaryYellow,
	colorTopBottom : skyBlue
};

enemyList['E01'] = enemy01;

//enemy
var enemy01 = {
	id : 'E01',
	x : 70,
	w : 75,
	spdX : 2,
	y : 60,
	h : 50,
	spdY : 5,
	name : "Chase",
	startFont : '30px Arial',
	wallFont : '20px Arial',
	topBottomFont : '10px Arial',
	color : myBlack,
	colorWall : grassGreen,
	colorTopBottom : appleRed
};

enemyList['E02'] = enemy02;

var enemy02 = {
	id : 'E01',
	x : 70,
	w : 75,
	spdX : 2,
	y : 60,
	h : 50,
	spdY : 5,
	name : "Chase",
	startFont : '30px Arial',
	wallFont : '20px Arial',
	topBottomFont : '10px Arial',
	color : myBlack,
	colorWall : grassGreen,
	colorTopBottom : appleRed
};

enemyList['E03'] = enemy03;

/*var enemy03 = {
	id : 'E01',
	x : 70,
	w : 75,
	spdX : 2,
	y : 60,
	h : 50,
	spdY : 5,
	name : "Chase",
	color : myBlack,
	colorWall : grassGreen,
	colorTopBottom : appleRed
};
*/

var ctxWidth = 500;
var ctxHeight = 500;
var rtSpacing = 100;
var bottomSpacing = 10;
var topSpacing = 30;

function updateEntity( something ) {
	
	something.x += something.spdX;
	something.y += something.spdY;
	
	//flips spdX if we hit either the left or the right sides
	if (something.x >= ctxWidth - rtSpacing || something.x <= 0) {// right side OR left side
		something.spdX *= -1;
		something.color = something.colorWall;
		something.font = something.wallFont;
	}

	// flip spdY if we hit either the ceiling OR the floor
	if (something.y >= ctxHeight - bottomSpacing || something.y <= topSpacing) {// || is a Boolean for "OR"
		something.spdY *= -1;
		something.color = something.colorTopBottom;
		something.font = something.topBottomFont;
	}
	
	ctx.font = something.font;
	ctx.fillStyle = something.color;
	ctx.fillRect(something.x, something.y, something.w, something.h);

}


function update() {
	ctx.clearRect(0, 0, ctxWidth, ctxHeight);
	updateEntity(player);
	
	for (var something in enemyList) {
		updateEntity(enemyList[something]);
	}
}

setInterval(update, 1);
