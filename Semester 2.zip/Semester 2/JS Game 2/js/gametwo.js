var ctx = document.getElementById("ctx").getContext("2d");

//width and height of the canvas
var ctxWidth = 900;
document.getElementById("ctx").width = ctxWidth;
var ctxHeight = 500;
var rtSpacing = 50;
var bottomSpacing = 100;
var topSpacing = 10;
var playerName = "Guest";

//custom color variables
var appleRed = "#FF0000";
var skyBlue = "#0000FF";
var grassGreen = "#00FF00";
var canaryYellow = "#FFFF00";
var myBlack = "#000000";
var myPink = "rgba(255, 102, 153, 0.5)";

//setting the start time
var timeWhenGameStarted = Date.now();
var currentTime;

//establishing the enemy array
var enemyList = {};

//player
var player = {
	x : 300,
	spdX : 3,
	y : 300,
	spdY : 7,
	w : 30,
	h : 30,
	name : "P",
	font : '30px Arial',
	wallFont : '60px Arial',
	topBottomFont : '10px Arial',
	color : myPink,
	colorWall : appleRed,
	colorTopBottom : skyBlue,
	hp : 10
};

//goal
var goal = {
	x : 825,
	y : 220,
	w : 50,
	h : 80,
	c : 'rgba(200, 50, 150, 0.5)'
};

//enemy
Enemy = function(id, passX, passY, spdX, spdY, w, h, passName, passFont, passWallFont, passTopBottomFont, passColor, passColorWall, passColorTopBottom) {

	var enemy = {
		id : id,
		x : passX,
		spdX : spdX,
		y : passY,
		spdY : spdY,
		w : w,
		h : h,
		name : passName,
		font : passFont,
		wallFont : passWallFont,
		topBottomFont : passTopBottomFont,
		color : passColor,
		colorWall : passColorWall,
		colorTopBottom : passColorTopBottom
	};

	enemyList[id] = enemy;

};

function addUserName() {
	
	playerName = document.getElementById("userName").value;
	
}

function updateCanvasWidth() {
	var message;
	var testWidth = document.getElementById("inputCanvasWidth").value;
	
	if (isNaN(testWidth) || testWidth < 500 || testWidth > 900) {
		message = "Input not valid, you entered " + testWidth;
		document.getElementById("showCanvasWidth").innerHTML = message;
		return;
	}
	else {
		message = "Valid input! Setting canvas width to " + gameWidth;
		document.getElementById("showCanvasWidth").innerHTML = message;
		ctx.width = testWidth;
		document.getElementById("ctx").width = gameWidth;
	}
}

//distance between entities
getDistanceBetweenEntity = function(entity1, entity2) {
	var dx = entity1.x - entity2.x;
	var dy = entity1.y - entity2.y;
	return Math.sqrt(dx * dx + dy * dy);

};

//testing for collision
testCollisionEntity = function(entity1, entity2) {

	var distance = getDistanceBetweenEntity(entity1, entity2);
	return distance < 50;

};

//mouse controls code
document.onmousemove = function(mouse){
	var mouseX = mouse.clientX;
	var mouseY = mouse.clientY;
	console.log('mouse x, y: ',mouseX,', ',mouseY);
	
	player.x = mouseX - 510;
	player.y = mouseY - 420;
	
};

updateEntity = function(something) {
	updateEntityPosition(something);
	drawEntity(something);
};

updateEntityPosition = function(something) {

	something.x += something.spdX;
	something.y += something.spdY;

	//flips spdX if we hit either the left or the right sides
	if (something.x >= ctxWidth - rtSpacing || something.x <= 0) {// right side OR left side
		something.spdX *= -1;
		something.color = something.colorWall;
		something.font = something.wallFont;
	}

	// flip spdY if we hit either the ceiling OR the floor
	if (something.y >= ctxHeight - bottomSpacing || something.y <= topSpacing) {// || is a Boolean for "OR"
		something.spdY *= -1;
		something.color = something.colorTopBottom;
		something.font = something.topBottomFont;
	}

};

drawEntity = function(something) {
	ctx.font = something.font;
	ctx.fillStyle = something.color;
	ctx.fillRect(something.x, something.y, something.w, something.h);
	ctx.fillStyle = goal.c;
	ctx.fillRect(goal.x, goal.y, goal.w, goal.h);
};

showPlayerName = function() {
	
	ctx.font = "20px Arial";
	ctx.fillStyle = "#FF0000";
	ctx.fillText("Player: "+ playerName, 10, 480);
	
};

update = function() {
	ctx.clearRect(0, 0, ctxWidth, ctxHeight);
	
	showPlayerName();
	
	var isColliding = testCollisionEntity(player, goal);
		if (isColliding) {
			var timeSurvived = Date.now() - timeWhenGameStarted;
			alert("You won! Game over! "+"Time = " + timeSurvived / 1000);
		}
	
	for (var key in enemyList) {
		
		updateEntity(enemyList[key]);
		var isColliding = testCollisionEntity(player, enemyList[key]);
		if (isColliding) {
			player.hp -= 1;
			if (player.hp < 0) {
				var timeSurvived = Date.now() - timeWhenGameStarted;
				alert("You lost! Game over! "+"Time = " + timeSurvived / 1000);
				player.hp = 10;
			}
		}
	}
	
	drawEntity(player);
	ctx.font = '30px Arial';
	ctx.fillStyle = '#FF0000';
	ctx.fillText("Shields: "+ player.hp,10,30);
	
	currentTime = (Date.now() - timeWhenGameStarted) / 1000;
	ctx.fillText('Seconds: ' + currentTime, 660, 30);
};

Enemy('E1', 50, 90, 2, 2, 50, 90, 'E01', '30px Arial', '60px Arial', '10px Arial', myBlack, grassGreen, appleRed);

Enemy('E2', 50, 140, 4, 2, 50, 140, 'E02', '60px Arial', '30px Arial', '15px Arial', grassGreen, myBlack, appleRed);

Enemy('E3', 50, 100, 2, 4, 50, 100, 'E03', '20px Arial', '80px Arial', '20px Arial', appleRed, grassGreen, myBlack);

Enemy('E4', 50, 100, 3, 3, 50, 100, 'E04', '60px Arial', '50px Arial', '25px Arial', grassGreen, myBlack, appleRed);

Enemy('E5', 50, 120, 3, 5, 50, 120, 'E05', '80px Arial', '30px Arial', '20px Arial', appleRed, grassGreen, myBlack);

setInterval(update, 20);