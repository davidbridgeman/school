var ctx = document.getElementById("ctx").getContext("2d");

ctx.font = '90px Arial';
ctx.fillStyle = '#FF0000';
ctx.globalAlpha = 0.5;

ctx.fillRect(50, 50, 375, 375);
ctx.clearRect(112,112,225,225);
ctx.fillStyle = '#0000FF';
ctx.fillText('Yes!', 130, 250);