var ctx = document.getElementById("ctx").getContext("2d");

var ctxWidth = 900;
var ctxHeight = 500;
var rtSpacing = 30;
var bottomSpacing = 10;
var topSpacing = 30;
var playerName = 'Guest';

var appleRed = "#FF0000";
var skyBlue = "#0000FF";
var grassGreen = "#00FF00";
var canaryYellow = "#FFFF00";
var myBlack = "#000000";
var myPink = "rgba(255, 102, 153, 0.5)";

var timeWhenGameStarted = Date.now();
var currentTime;
// reserve a name for this var

//console.log("Game started: ", timeWhenGameStarted);

var enemyList = {};

// player as an object
var player = {
	x : 20,
	spdX : 3,
	y : 250,
	spdY : 7,
	name : "P",
	font : '30px Arial',
	wallFont : '60px Arial',
	topBottomFont : '10px Arial',
	color : myBlack,
	colorWall : appleRed,
	colorTopBottom : skyBlue,
	hp : 10
};
// end of player

// make a goal as an object
var goal = {
	x : 825,
	y : 220,
	w : 50,
	h : 80,
	c : 'rgba(200, 50, 150, 0.3)'
};

// this is a "Constructor"
Enemy = function(id, passX, passY, spdX, spdY, passName, passFont, passWallFont, passTopBottomFont, passColor, passColorWall, passColorTopBottom) {

	var enemy = {
		id : id,
		x : passX,
		spdX : spdX,
		y : passY,
		spdY : spdY,
		name : passName,
		font : passFont,
		wallFont : passWallFont,
		topBottomFont : passTopBottomFont,
		color : passColor,
		colorWall : passColorWall,
		colorTopBottom : passColorTopBottom
	};

	enemyList[id] = enemy;

};
// end of Enemy() constructor

function addUserName() {
	
	playerName = document.getElementById("userName").value;
	
}

getDistanceBetweenEntity = function(entity1, entity2) {
	var dx = entity1.x - entity2.x;
	var dy = entity1.y - entity2.y;
	return Math.sqrt(dx * dx + dy * dy);

};

testCollisionEntity = function(entity1, entity2) {

	var distance = getDistanceBetweenEntity(entity1, entity2);
	return distance < 50;

};

document.onmousemove = function(mouse) {
	var mouseX = mouse.clientX;
	var mouseY = mouse.clientY;
	//console.log('mouse x, y: ', mouseX, ', ', mouseY);

	player.x = mouseX - 12;
	// Canvas numbers, not document numbers
	player.y = mouseY - 130;

};

updateEntity = function(something) {
	updateEntityPosition(something);
	drawEntity(something);
};

updateEntityPosition = function(something) {

	something.x += something.spdX;
	something.y += something.spdY;

	//flips spdX if we hit either the left or the right sides
	if (something.x >= ctxWidth - rtSpacing || something.x <= 0) {// right side OR left side
		something.spdX *= -1;
		something.color = something.colorWall;
		something.font = something.wallFont;
	}

	// flip spdY if we hit either the ceiling OR the floor
	if (something.y >= ctxHeight - bottomSpacing || something.y <= topSpacing) {// || is a Boolean for "OR"
		something.spdY *= -1;
		something.color = something.colorTopBottom;
		something.font = something.topBottomFont;
	}

};

drawEntity = function(something) {
	ctx.font = something.font;
	ctx.fillStyle = something.color;
	ctx.fillText(something.name, something.x, something.y);
	ctx.fillStyle = goal.c;
	ctx.fillRect(goal.x, goal.y, goal.w, goal.h);

	
};


showPlayerName = function(){

// show player name
	ctx.font = "20px Arial";
	ctx.fillStyle = "#FF0000";
	ctx.fillText("Player: " + playerName, 10, ctxHeight-30);
	
};


update = function() {
	ctx.clearRect(0, 0, ctxWidth, ctxHeight);
	
	showPlayerName();

	for (var key in enemyList) {
		updateEntity(enemyList[key]);
		//test for collision
		var isColliding = testCollisionEntity(player, enemyList[key]);
		if (isColliding) {

			//player.hp = player.hp - 1;
			player.hp -= 1;
			// "Decrement" counting down
			if (player.hp < 0) {
				var timeSurvived = Date.now() - timeWhenGameStarted;
				alert("Game is OVER!" + " Time = " + timeSurvived / 1000);
				timeWhenGameStarted = Date.now();
				player.hp = 10;
			}
		}
	}// end of for

	//tracks mouse when mouse moves, wanders off when mouse stops
	//updateEntity(player);
	//tracks mouse when mouse moves, stops when mouse stops
	drawEntity(player);
	ctx.font = '30px Arial';
	ctx.fillStyle = '#FF0000';
	ctx.fillText('Shields: ' + player.hp, 0, 30);

	//currentTime  =  Math.trunc((Date.now() - timeWhenGameStarted)/1000);
	currentTime = (Date.now() - timeWhenGameStarted) / 1000;
	ctx.fillText('Seconds: ' + currentTime, 600, 30);

};
// end of update()

Enemy('E1', 770, 60, 2, 5, 'E01', '30px Arial', '60px Arial', '10px Arial', myBlack, grassGreen, appleRed);

Enemy('E2', 800, 50, 3, 4, 'E02', '60px Arial', '30px Arial', '15px Arial', grassGreen, myBlack, appleRed);

Enemy('E3', 450, 350, -3, 7, 'E03', '20px Arial', '80px Arial', '20px Arial', appleRed, grassGreen, myBlack);

Enemy('E4', 200, 300, -3, 4, 'E04', '60px Arial', '30px Arial', '15px Arial', grassGreen, myBlack, appleRed);

Enemy('E5', 175, 250, -3, 7, 'E05', '20px Arial', '80px Arial', '20px Arial', appleRed, grassGreen, myBlack);

setInterval(update, 100);

// FINIS!  THE END!
