var optionsCost;
var shippingCost;
var sizeCost;
var salesTax;
var finalCost;

function calculateTotal() {
	finalCost = 0.00;
	optionsCost = orderForm.grand_total.value;
	shippingCost = orderForm.finalShip.value;
	sizeCost = orderForm.lineSize.value;
	finalCost = accounting.unformat(optionsCost) + accounting.unformat(shippingCost) + accounting.unformat(sizeCost);
	salesTax = 0.06 * finalCost;
	finalCost += salesTax;
	finalCost = accounting.formatMoney(finalCost);
	
	document.getElementById("line_sales").value += accounting.formatMoney(salesTax);
	document.getElementById("line_sum").value += accounting.formatMoney(finalCost);
}

function setSize(size) {
	var price = 0.0;
	document.getElementById("mySize").value = size;
	
	if (size == "Small") {
		price = 9.95;
		document.getElementById("lineSize").value = accounting.formatMoney(price);
	}
	else if (size == "Medium") {
		price = 14.95;
		document.getElementById("lineSize").value = accounting.formatMoney(price);
	}
	else if (size == "Large") {
		price = 19.95;
		document.getElementById("lineSize").value = accounting.formatMoney(price);
	}
	else {
		document.getElementById("lineSize").value = "Error";
	}
}

function get_data(orderForm) {
			
	var order_data = "This order is... \n";
	for ( i = 0; i < orderForm.line.length; i++) {
		if (orderForm.line[i].value == "")
			orderForm.line[i].value = "0";
		order_data += "Line " + i + ", Quantity = " + orderForm.line[i].value + ", Price = " + accounting.formatMoney(orderForm.line_sum[i].value) + "\n";
	}
	if (orderForm.grand_total.value == "") {
		orderForm.grand_total.value = "Nothing yet";
	}
	order_data += "Total order value = " + orderForm.grand_total.value;
	order_data += "\n" + "Size total is " + sizeCost + "\n";
	order_data += "Shipping total is " + shippingCost + "\n";
	document.confirmationForm.order.value = order_data;
}

function setShipper() {
	var shipDropDown = document.getElementById("selectShipper");
	var displayShipper = document.getElementById("previewShipper");
	var price;
	
	if (shipDropDown.options[shipDropDown.selectedIndex].text == "Pickup") {
		price = parseFloat(0.00);
		displayShipper.value = "Pickup = $0";
		document.orderForm.finalShip.value = accounting.formatMoney(price);
	}
	else if (shipDropDown.options[shipDropDown.selectedIndex].text == "UPS") {
		price = parseFloat(4.95);
		displayShipper.value = "UPS = $4.95";
		document.orderForm.finalShip.value = accounting.formatMoney(price);
	}
	else if (shipDropDown.options[shipDropDown.selectedIndex].text == "FedEx") {
		price = parseFloat(6.95);
		displayShipper.value = "FedEx = $6.95";
		document.orderForm.finalShip.value = accounting.formatMoney(price);
	}
}
	
function count(orderForm, lineNumber, itemCost) {
			
	orderForm.line_sum[lineNumber].value = 
	orderForm.line[lineNumber].value * itemCost;
			
	var grandTotal = 0;
	for ( i = 0; i < orderForm.line_sum.length; i++) {
		grandTotal += Math.ceil(orderForm.line_sum[i].value * 1000) / 1000;
	}
	grandTotal = Math.round(grandTotal * 1000) / 1000;
	orderForm.grand_total.value = accounting.formatMoney(grandTotal);
}
	
function init() {
			
	document.orderForm.reset();
	document.orderForm.line[0].select();
	document.orderForm.line[0].focus();
	document.confirmationForm.order.value = "";
}
		
window.onload = init;