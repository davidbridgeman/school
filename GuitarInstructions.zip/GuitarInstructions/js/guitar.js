$(document).ready(function() {
	
	var imageName = [
	"images/lespaul.jpg",
	"images/strat.jpg",
	"images/tele.jpg",
	"images/dreadnought.jpg",
	"images/parlour.jpg",
	"images/jumbo.jpg",
	];
	
	var imageText = [
	"Les Paul",
	"Stratocaster",
	"Telecaster",
	"Dreadnought",
	"Parlour",
	"Jumbo",
	];
	
	var indexNum = 1;
	
	$("#picture").click(function() {
		
		$("#picture").fadeOut(200, function() {
			
			$("#picture").attr("src", imageName[indexNum]);
			$("#slidetext").text(imageText[indexNum]).fadeIn(200);
			
				indexNum++;
				if (indexNum > 5){
					indexNum = 0;
				}
				
				$("#picture").fadeIn(200);
			
		});
		
	});
	
	$("#hide1").hide();
	$("#hide2").hide();
	$("#hide3").hide();

	$("#click1").click(function() {
		$("#hide1").slideToggle(1000);
		$("#hide1").show();
	});

	$("#click2").click(function() {
		$("#hide2").slideToggle(1000);
		$("#hide2").show();
	});

	$("#click3").click(function() {
		$("#hide3").slideToggle(1000);
		$("#hide3").show();

	});
	
	$('#btnadd').on('click', function() {
		
		var n1 = parseInt($('#txtn1').val());
		var n2 = parseInt($('#txtn2').val());
		// var n1 = parseFloat($('#txtn1').val());
		// var n2 = parseFloat($('#txtn2').val());
		// var n1 = $('txtn2').val();
		// var n1 = $('txtn2').val();
		var r = n1 + n2;
		alert("Result is " + r);
		$('#result1').val(r);
		return false;
	});
	
	$('#btnclear1').on('click', function(){
		
		$('#txtn1').val('');
		$('#txtn2').val('');
		$('#result').val('');
	});
});