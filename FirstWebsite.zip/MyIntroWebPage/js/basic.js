$(document).ready(function() {

	$("p").hide();
	$("#topPicture").hide();

	$("h1").click(function() {
		$(this).next().fadeToggle(300);

	});

	/* jq02 background buttons and selectors*/

	$("#testbutton").click(function() {
		$("#jq02").css("background-color", "red");
	});

	/* jq03 mouse effects*/

	$("h3").mousedown(function() {
		$(this).css("background-color", "#0000FF");
	});

	$("h3").mouseup(function() {
		$(this).css("background-color", "#00FF00");
	});
	
	$("h3").mouseenter(function() {
		$(this).css("font-size", "3em");
	});

	$("h3").mouseleave(function() {
		$(this).css("font-size", "2em");
		/* $(this).unbind(); makes it happen one time only */
	});
	
});
