$(document).ready(function() {
	
	$("p").hide();
	$("#topPicture").hide();
	
	$("h1").click(function() {
		$(this).next().fadeToggle(300);
	
	});	
	
	/* start of jq02 how to use background buttons and selectors*/
	
	$("#testbutton").click(function() {
		$("#jq02").css("background-color","red");
	});
	
});
